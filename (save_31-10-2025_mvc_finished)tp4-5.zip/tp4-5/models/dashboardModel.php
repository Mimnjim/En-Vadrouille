<?php
// dashboardModel.php

// --- Utilisateurs ---
function getAllUsers($cnx) {
    $stmt = $cnx->query("SELECT id_user, username, profile_photo FROM utilisateurs ORDER BY id_user ASC");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function updateUser($cnx, $id, $username, $profile_photo = null) {
    if ($profile_photo) {
        $stmt = $cnx->prepare("UPDATE utilisateurs SET username = ?, profile_photo = ? WHERE id_user = ?");
        $stmt->execute([$username, $profile_photo, $id]);
    } else {
        $stmt = $cnx->prepare("UPDATE utilisateurs SET username = ? WHERE id_user = ?");
        $stmt->execute([$username, $id]);
    }
}

function deleteUser($cnx, $id) {
    $stmt = $cnx->prepare("DELETE FROM utilisateurs WHERE id_user = ?");
    $stmt->execute([$id]);
}

// --- Commentaires ---
function getAllComments($cnx) {
    $stmt = $cnx->query("
        SELECT c.id_commentaire, c.commentaire, c.date, u.username, b.titre AS billet_titre
        FROM commentaires c
        JOIN utilisateurs u ON c.fk_auteur = u.id_user
        JOIN billets b ON c.fk_comment_billet = b.id_billet
        ORDER BY c.date DESC
    ");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function updateComment($cnx, $id, $commentaire) {
    $stmt = $cnx->prepare("UPDATE commentaires SET commentaire = ? WHERE id_commentaire = ?");
    $stmt->execute([$commentaire, $id]);
}

function deleteComment($cnx, $id) {
    $stmt = $cnx->prepare("DELETE FROM commentaires WHERE id_commentaire = ?");
    $stmt->execute([$id]);
}

// --- Upload photo ---
function uploadProfilePhoto($file) {
    $target_dir = "../images/profile/";
    $filename = uniqid() . "_" . basename($file["name"]);
    move_uploaded_file($file["tmp_name"], $target_dir . $filename);
    return substr($target_dir . $filename, 3); // enlever ../ si nécessaire pour la vue
}
