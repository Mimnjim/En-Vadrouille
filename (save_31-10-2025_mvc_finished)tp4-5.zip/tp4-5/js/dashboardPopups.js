// dashboardPopups.js

// --- POPUP SUPPRESSION ---
document.querySelectorAll('.delete').forEach(btn => {
    btn.addEventListener('click', e => {
        e.preventDefault();

        const row = e.target.closest('tr');
        const id = row.children[0].textContent; // ID dans la première colonne
        const type = row.closest('table').parentElement.classList.contains('users-managed') ? 'user' : 'comment';

        document.getElementById('delete-id').value = id;
        document.getElementById('delete-type').value = type;

        const message = type === 'user'
            ? "Voulez-vous vraiment supprimer cet utilisateur ?"
            : "Voulez-vous vraiment supprimer ce commentaire ?";
        document.getElementById('delete-message').textContent = message;

        document.querySelector('.popup-delete').style.display = 'flex';
    });
});

// --- POPUP MODIFICATION ---
document.querySelectorAll('.edit').forEach(btn => {
    btn.addEventListener('click', e => {
        e.preventDefault();

        const row = e.target.closest('tr');
        const id = row.children[0].textContent;
        const type = row.closest('table').parentElement.classList.contains('users-managed') ? 'user' : 'comment';

        document.getElementById('edit-id').value = id;
        document.getElementById('edit-type').value = type;

        if (type === 'user') {
            document.getElementById('edit-username').value = row.children[2].textContent;
            document.getElementById('edit-comment-section').style.display = 'none';
            document.getElementById('edit-photo-section').style.display = 'block';
        } else {
            document.getElementById('edit-username').value = row.children[1].textContent;
            document.getElementById('edit-comment').value = row.children[2].textContent;
            document.getElementById('edit-comment-section').style.display = 'block';
            document.getElementById('edit-photo-section').style.display = 'none';
        }

        document.querySelector('.popup-edit').style.display = 'flex';
    });
});

// --- FERMETURE DES POPUPS ---
document.querySelectorAll('.close-popup, .cancel').forEach(btn => {
    btn.addEventListener('click', () => {
        btn.closest('.popup').style.display = 'none';
    });
});
