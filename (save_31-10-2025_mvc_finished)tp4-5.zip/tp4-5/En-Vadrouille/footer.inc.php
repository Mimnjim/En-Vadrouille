<footer>
    <p>© 2024 En Vadrouille. Tous droits réservés.</p>
</footer>