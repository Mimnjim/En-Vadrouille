<?php
session_start();
include_once(__DIR__ . '/../config/cnx.inc.php');
include_once(__DIR__ . '/../models/utilisateurModel.php'); // modèle pour utilisateurs

$erreur = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom_utilisateur = $_POST['username'] ?? '';
    $mot_de_passe = $_POST['password'] ?? '';
    $mot_de_passe2 = $_POST['password2'] ?? '';

    if (empty($nom_utilisateur) || empty($mot_de_passe) || empty($mot_de_passe2)) {
        $erreur = "Veuillez remplir tous les champs.";
    } elseif ($mot_de_passe !== $mot_de_passe2) {
        $erreur = "Les mots de passe ne correspondent pas.";
    } else {
        // Vérifie si le nom d'utilisateur existe déjà
        if (getUtilisateurByUsername($cnx, $nom_utilisateur)) {
            $erreur = "Nom d'utilisateur déjà utilisé.";
        } else {
            // Création du mot de passe hashé et insertion
            $hashed_password = password_hash($mot_de_passe, PASSWORD_BCRYPT);
            createUtilisateur($cnx, $nom_utilisateur, $hashed_password);
            header("Location: /controllers/connexionController.php");
            exit();
        }
    }
}

// Affiche la vue
include(__DIR__ . '/../views/inscriptionView.php');
