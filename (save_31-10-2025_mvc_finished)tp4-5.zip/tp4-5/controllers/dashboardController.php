<?php
session_start();
include_once(__DIR__ . '/../config/cnx.inc.php');
include_once(__DIR__ . '/../models/dashboardModel.php');

// Vérification accès admin
if (!isset($_SESSION['username']) || $_SESSION['username'] !== 'admin') {
    header("Location: ../index.php");
    exit();
}

$admin_logged_in = true;

// --- TRAITEMENT DES FORMULAIRES ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $type = $_POST['type'] ?? '';
    $id = $_POST['id'] ?? '';

    if ($action === 'delete') {
        if ($type === 'user') deleteUser($cnx, $id);
        if ($type === 'comment') deleteComment($cnx, $id);
        header("Location: dashboardController.php");
        exit();
    }

    if ($action === 'edit') {
        if ($type === 'user') {
            $username = $_POST['username'] ?? '';
            $profile_photo = null;
            if (isset($_FILES['profile_photo']) && $_FILES['profile_photo']['tmp_name']) {
                $profile_photo = uploadProfilePhoto($_FILES['profile_photo']);
            }
            updateUser($cnx, $id, $username, $profile_photo);
        } elseif ($type === 'comment') {
            $commentaire = $_POST['commentaire'] ?? '';
            updateComment($cnx, $id, $commentaire);
        }
        header("Location: dashboardController.php");
        exit();
    }
}

// --- Récupération des données pour la vue ---
$users = getAllUsers($cnx);
$comments = getAllComments($cnx);

// --- Affichage de la vue ---
include(__DIR__ . '/../views/dashboardView.php');
