<?php
function ajouterCommentaire($cnx, $username, $id_billet, $commentaire) {
    $stmtIdAuteur = $cnx->prepare("SELECT id_user FROM utilisateurs WHERE username = :username");
    $stmtIdAuteur->execute([':username' => $username]);
    $idAuteur = $stmtIdAuteur->fetch(PDO::FETCH_ASSOC)['id_user'];

    $stmt = $cnx->prepare("
        INSERT INTO commentaires (fk_auteur, date, fk_comment_billet, commentaire)
        VALUES (:idAuteur, NOW(), :id_billet, :commentaire)
    ");
    $stmt->execute([
        ':idAuteur' => $idAuteur,
        ':id_billet' => $id_billet,
        ':commentaire' => $commentaire
    ]);
}

function getCommentairesByBillet($cnx, $id_billet) {
    $stmt = $cnx->prepare("
        SELECT c.commentaire, c.date, u.username, u.profile_photo
        FROM commentaires c
        JOIN utilisateurs u ON c.fk_auteur = u.id_user
        WHERE c.fk_comment_billet = ?
        ORDER BY c.date DESC
    ");
    $stmt->execute([$id_billet]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
