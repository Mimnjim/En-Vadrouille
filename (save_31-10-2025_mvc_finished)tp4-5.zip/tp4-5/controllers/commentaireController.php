<?php
session_start();
include_once('../config/cnx.inc.php');
include_once('../models/commentaireModel.php'); // à créer

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!isset($_SESSION['username'])) {
        header('Location: connexionController.php');
        exit();
    }

    $id_billet = $_POST['id_billet'] ?? null;
    $commentaire = $_POST['comment'] ?? null;
    $username = $_SESSION['username'];

    if ($id_billet && $commentaire && $username) {
        ajouterCommentaire($cnx, $username, $id_billet, $commentaire);
        header("Location: billetController.php?id=$id_billet");
        exit();
    } else {
        echo "Veuillez remplir tous les champs.";
    }
}
