<?php
session_start();
include_once(__DIR__ . '/../config/cnx.inc.php');
include_once(__DIR__ . '/../models/billetModel.php');

// On vérifie si un admin est connecté
$admin_loggned_in = isset($_SESSION['username']) && $_SESSION['username'] === 'admin';

// On récupère les derniers billets depuis le modèle
$billets = getDerniersBillets($cnx);

// On affiche la vue
include(__DIR__ . '/../views/indexView.php');
