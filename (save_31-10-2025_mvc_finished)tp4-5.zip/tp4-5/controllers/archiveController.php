<?php
session_start();
include_once(__DIR__ . '/../config/cnx.inc.php');
include_once(__DIR__ . '/../models/billetModel.php');

// Vérifier si admin
$admin_logged_in = isset($_SESSION['username']) && $_SESSION['username'] === 'admin';

// Récupérer tous les billets
$billets = getAllBillets($cnx);

// Afficher la vue
include(__DIR__ . '/../views/archiveView.php');
?>
