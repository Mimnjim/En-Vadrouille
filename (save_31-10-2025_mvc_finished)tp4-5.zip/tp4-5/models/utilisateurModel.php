<?php
function getUtilisateurByUsername($cnx, $username) {
    $stmt = $cnx->prepare("SELECT * FROM utilisateurs WHERE username = :username");
    $stmt->execute([':username' => $username]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function createUtilisateur($cnx, $username, $hashed_password) {
    $stmt = $cnx->prepare("INSERT INTO utilisateurs (username, password) VALUES (:username, :password)");
    $stmt->execute([
        ':username' => $username,
        ':password' => $hashed_password
    ]);
}

function updateProfilePhoto($cnx, $username, $photo_path) {
    $stmt = $cnx->prepare("UPDATE utilisateurs SET profile_photo = :profile_photo WHERE username = :username");
    $stmt->execute([
        ':profile_photo' => $photo_path,
        ':username' => $username
    ]);
    return $stmt->rowCount() > 0;
}