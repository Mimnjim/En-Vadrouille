<?php
session_start();
include_once(__DIR__ . '/../config/cnx.inc.php');
include_once(__DIR__ . '/../models/billetModel.php');
include_once(__DIR__ . '/../models/commentaireModel.php');

// Vérifier si admin
$admin_logged_in = isset($_SESSION['username']) && $_SESSION['username'] === 'admin';

// Récupérer l'ID du billet
$id_billet = $_POST['id_billet'] ?? $_GET['id'] ?? null;

if (!$id_billet) {
    header('Location: ../index.php');
    exit();
}
// --- GESTION ADMIN : modification / suppression ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $admin_logged_in) {
    $action = $_POST['action'] ?? null;

    if ($action === 'delete') {
        $billet = getImageBillet($cnx, $id_billet);
        if ($billet && file_exists($billet['image'])) unlink($billet['image']);
        supprimerBillet($cnx, $id_billet);
        header('Location: ../archive.php');
        exit();
    }

    if ($action === 'edit') {
        $titre = $_POST['titre_edit'];
        $description = $_POST['description_edit'];
        $image_path = !empty($_FILES['image_edit']['name']) ? uploadImage($_FILES['image_edit']) : null;        
        modifierBillet($cnx, $id_billet, $titre, $description, $image_path);
        header("Location: ../controllers/billetController.php?id=$id_billet");
        exit();
    }
}

// --- Récupérer les infos du billet et commentaires ---
$billet = getBilletById($cnx, $id_billet);
$commentaires = getCommentairesByBillet($cnx, $id_billet);

// Afficher la vue
include(__DIR__ . '/../views/billetView.php');

