<?php
session_start();
include_once(__DIR__ . '/../config/cnx.inc.php');
include_once(__DIR__ . '/../models/utilisateurModel.php'); // nouveau modèle pour gérer les utilisateurs

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom_utilisateur = $_POST['username'] ?? '';
    $mot_de_passe = $_POST['password'] ?? '';

    if (!empty($nom_utilisateur) && !empty($mot_de_passe)) {
        $user = getUtilisateurByUsername($cnx, $nom_utilisateur);

        if ($user && password_verify($mot_de_passe, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            header("Location: ../index.php");
            exit();
        } else {
            $erreur = "Nom d'utilisateur ou mot de passe incorrect.";
        }
    } else {
        $erreur = "Veuillez remplir tous les champs.";
    }
}

// Affiche la vue (avec éventuellement un message d'erreur)
include(__DIR__ . '/../views/connexionView.php');
