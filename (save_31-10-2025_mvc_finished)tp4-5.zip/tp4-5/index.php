<?php
// index.php à la racine

require_once('controllers/indexController.php');
