<?php
// Définir un préfixe selon l'endroit d'où le header est inclus
$prefix = '';
if (strpos($_SERVER['PHP_SELF'], '/controllers/') !== false) {
    $prefix = '../';
}
?>

<header>
    <a href="<?= $prefix ?>index.php">En Vadrouille</a>

    <?php
        if(isset($_SESSION['username']) && $_SESSION['username'] === 'admin') {  
            echo "<h1 class='admin-connected'>Vous êtes connecté.e.s en tant qu'Admin</h1>";
        }

        if(isset($_SESSION['username'])) {
            echo "<nav class='nav-connected'>";
            if($_SESSION['username'] === 'admin') {
                echo "<a href='{$prefix}controllers/dashboardController.php' class='dashboard'>Tableau de bord</a>";
            }    
            echo "<a href='{$prefix}controllers/profileController.php'><i class='bx bx-user-circle'></i></a>";
            echo "</nav>";
        } else {
            echo "<nav><a href='{$prefix}controllers/connexionController.php'>Se connecter</a></nav>";
        }
    ?>
</header>
