<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($billet['titre']) ?></title>
    <link rel="stylesheet" href="../styles/global.css">
    <link rel="stylesheet" href="../styles/billet.css">
    <link href='https://cdn.boxicons.com/fonts/basic/boxicons.min.css' rel='stylesheet'>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=BBH+Sans+Bogle&display=swap" rel="stylesheet">
</head>
<body>
<?php include_once('header.inc.php'); ?>

<!-- Popup de suppression -->
<div class="popup popup-delete">
    <div class="popup-content">
        <span class="close-popup">&times;</span>
        <h2>Supprimer le billet</h2>
        <p>Êtes-vous sûr de vouloir supprimer ce billet ?</p>
        <form action="../controllers/billetController.php" method="POST">
            <input type="hidden" name="id_billet" value="<?= $id_billet ?>">
            <input type="hidden" name="action" value="delete">
            <button type="submit" class="confirm">Oui, supprimer</button>
            <button type="button" class="cancel">Non, annuler</button>
        </form>
    </div>
</div>

<!-- Popup de modification -->
<div class="popup popup-edit">
    <div class="popup-content">
        <span class="close-popup">&times;</span>
        <h2>Modifier le billet</h2>
        <form action="../controllers/billetController.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="id_billet" value="<?= $id_billet ?>">
            <input type="hidden" name="action" value="edit">

            <div class="form-group">
                <label for="titre_edit">Titre</label>
                <input type="text" name="titre_edit" id="titre_edit" value="<?= $billet['titre'] ?>" required>
            </div>

            <div class="form-group">
                <label for="description_edit">Description</label>
                <textarea name="description_edit" id="description_edit" rows="5" required><?= htmlspecialchars($billet['description']) ?></textarea>
            </div>

            <div class="form-group">
                <label for="image_edit">Image (laisser vide pour ne pas changer)</label>
                <input type="file" name="image_edit" id="image_edit" accept="image/*">
            </div>

            <button type="submit" class="confirm">Enregistrer les modifications</button>
            <button type="button" class="cancel">Annuler</button>
        </form>
    </div>
</div>

<main>
    <a href='../controllers/archiveController.php' class='go-to-archive'>Aller aux archives</a>

    <div class='infos-billet'>
        <div class='infos'>
            <span>Publié le <?= $billet['date'] ?> par Admin</span>
            <hr>
            <h1 class='title-section'><?= htmlspecialchars($billet['titre']) ?></h1>
        </div>

        <?php if ($admin_logged_in): ?>
            <div class='menu-admin'>
                <a href='#' class='menu-toggle'><i class='bx bx-dots-vertical-rounded'></i></a>
                <div class='display-menu-list-admin'>
                    <a href='#' class='delete'><i class='bx bx-trash'></i> Supprimer le billet</a> 
                    <a href='#' class='edit'><i class='bx bx-edit'></i> Modifier le billet</a>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <section class='billet-content'>
        <img src='../<?= htmlspecialchars($billet['image']) ?>' alt='Image du billet <?= htmlspecialchars($billet['titre']) ?>'>
        <p><?= nl2br(htmlspecialchars($billet['description'])) ?></p>
    </section>

    <section class="comments-section">
        <h2>Commentaires</h2>
        <span class="toggleComments">> Afficher les commentaires</span>
        <div class="list-comments">
            <?php if(count($commentaires) > 0): ?>
                <?php foreach($commentaires as $commentaire): ?>
                    <?php 
                        $photo = !empty($commentaire['profile_photo']) 
                            ? htmlspecialchars($commentaire['profile_photo']) 
                            : 'images/profile/default_profile.png';
                    ?>
                    <div class='comment'>
                        <div class='img-user'>
                            <img src='../<?= $photo ?>' alt='Photo de profil de <?= htmlspecialchars($commentaire['username']) ?>'>
                            <h3><?= htmlspecialchars($commentaire['username']) ?> - <?= htmlspecialchars($commentaire['date']) ?></h3>
                        </div>
                        <p><?= nl2br(htmlspecialchars($commentaire['commentaire'])) ?></p>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>Aucun commentaire pour le moment. Soyez le premier à commenter !</p>
            <?php endif; ?>
        </div>

        <?php if(isset($_SESSION['username'])): ?>
            <div class='add-comment-section'>
                <h3>Ajouter un commentaire</h3>
                <form action='../controllers/commentaireController.php' method='post' class='comment-form'>
                    <p>Utilisateur : <?= htmlspecialchars($_SESSION['username']) ?></p>
                    <input type='hidden' name='id_billet' value='<?= $id_billet ?>'>
                    <label for='comment'>Commentaire :</label><br>
                    <textarea id='comment' name='comment' rows='4' required></textarea>
                    <button type='submit'>Envoyer</button>
                </form>
            </div>
        <?php endif; ?>
    </section>
</main>

<?php include_once('footer.inc.php'); ?>
<script src="../js/popup_delete_edit.js"></script>
<script>
    // Toggle comments
    const commentsSection = document.querySelector('.comments-section');
    const commentsList = document.querySelector('.list-comments');
    const toggleComments = commentsSection.querySelector('span');
    toggleComments.addEventListener('click', () => {
        if(commentsList.style.display === 'block') {
            commentsList.style.display = 'none';
            toggleComments.textContent = '> Afficher les commentaires';
        } else {
            commentsList.style.display = 'block';
            toggleComments.textContent = '> Masquer les commentaires';
        }
    });
</script>
</body>
</html>
