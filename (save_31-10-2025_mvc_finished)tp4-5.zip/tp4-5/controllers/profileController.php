<?php
session_start();
include_once('../config/cnx.inc.php');
include_once('../models/utilisateurModel.php');

// Vérifier que l'utilisateur est connecté
if(!isset($_SESSION['username'])){
    header("Location: ../connexion.php");
    exit();
}

$username = $_SESSION['username'];
$user = getUtilisateurByUsername($cnx, $username); // récupère profile_photo, username, etc.

// ------------------------
// Traitement de l'upload
// ------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['profile_photo'])) {

    $profile_photo = $_FILES['profile_photo'];

    if ($profile_photo['error'] === 0) {
        // Dossier sur le serveur pour move_uploaded_file
        $target_dir_server = "../images/profile/";

        // Nom unique du fichier
        $profile_photo_name = uniqid() . "_" . basename($profile_photo['name']);

        // Chemin web pour la base de données et affichage (depuis la racine du site)
        $target_file_web = "/images/profile/" . $profile_photo_name; 

        // Chemin serveur pour déplacer le fichier
        $target_file_server = $target_dir_server . $profile_photo_name;

        // Déplacer le fichier
        if(move_uploaded_file($profile_photo['tmp_name'], $target_file_server)) {
            $success = updateProfilePhoto($cnx, $username, $target_file_web);
            if($success) {
                $_SESSION['profile_photo'] = $target_file_web;
                // Mettre à jour $user pour que la vue affiche la nouvelle photo
                $user['profile_photo'] = $target_file_web;
                $message = "Photo de profil mise à jour avec succès !";
            } else {
                $error = "Erreur lors de la mise à jour en base.";
            }
        } else {
            $error = "Erreur lors du téléchargement de la photo.";
        }

    } else {
        $error = "Erreur lors de l'upload : code " . $profile_photo['error'];
    }
}

// ------------------------
// Affichage du profil
// ------------------------
include('../views/profileView.php');
