<?php
function ajouterBillet($cnx, $titre, $description, $image_path) {
    $stmt = $cnx->prepare("
        INSERT INTO billets (fk_proprietaire, titre, description, date, image)
        VALUES (1, :titre, :description, NOW(), :image)
    ");
    $stmt->execute([
        ':titre' => $titre,
        ':description' => $description,
        ':image' => $image_path
    ]);
}

function supprimerBillet($cnx, $id) {
    $stmt = $cnx->prepare("DELETE FROM billets WHERE id_billet = ?");
    $stmt->execute([$id]);
}

function getImageBillet($cnx, $id) {
    $stmt = $cnx->prepare("SELECT image FROM billets WHERE id_billet = ?");
    $stmt->execute([$id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function modifierBillet($cnx, $id, $titre, $description, $image_path = null) {
    if ($image_path) {
        $stmt = $cnx->prepare("UPDATE billets SET titre = ?, description = ?, image = ? WHERE id_billet = ?");
        $stmt->execute([$titre, $description, $image_path, $id]);
    } else {
        $stmt = $cnx->prepare("UPDATE billets SET titre = ?, description = ? WHERE id_billet = ?");
        $stmt->execute([$titre, $description, $id]);
    }
}

function getDerniersBillets($cnx, $limite = 3) {
    $stmt = $cnx->prepare("SELECT * FROM billets ORDER BY date DESC LIMIT :limite");
    $stmt->bindValue(':limite', $limite, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function getBilletById($cnx, $id) {
    $stmt = $cnx->prepare("SELECT * FROM billets WHERE id_billet = ?");
    $stmt->execute([$id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

// --- Fonction utilitaire pour image ---
function uploadImage($file) {
    $target_dir = "../images/sorties-img/";
    $filename = uniqid() . "_" . basename($file["name"]);
    $target_file = $target_dir . $filename;
    move_uploaded_file($file["tmp_name"], $target_file);
    return substr($target_file, 3); // enlever "../" si nécessaire pour la vue
}

function getAllBillets($cnx) {
    $stmt = $cnx->query("SELECT * FROM billets ORDER BY date DESC");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}