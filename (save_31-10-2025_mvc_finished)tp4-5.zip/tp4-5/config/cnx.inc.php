<?php 
    // $cnx = new PDO('mysql: host=localhost;dbname=te_tp4-5-php;', 'te_mimnjim', 'Tg81lyFeccP2fAZw')
    $cnx = new PDO('mysql:host=localhost;dbname=te_tp4-5-php;', 'root', '');
?>